from django.contrib import admin
from project_app.models import Volunteer
# Register your models here.
admin.site.register(Volunteer)