
from django.urls import path,include
from project_app import views

urlpatterns = [
    path('reg',views.registration),
    path('home',views.home),
    path('about',views.about)
]