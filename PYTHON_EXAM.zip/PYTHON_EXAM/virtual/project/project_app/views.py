from django.shortcuts import render
from project_app.models import Volunteer
# Create your views here.
def home(request):
    return render(request,'home.html')

def about(request):
    return render(request,'about.html')

def registration(request):
    if request.method=='POST':
        name=request.POST.get("name")
        print(name)
        v=Volunteer(name=name)
        v.save()

    return render(request,'reg.html')